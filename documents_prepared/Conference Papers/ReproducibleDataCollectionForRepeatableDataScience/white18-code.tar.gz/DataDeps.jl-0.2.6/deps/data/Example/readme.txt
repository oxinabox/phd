This folder is an example of data dependency that is directly included in the git repo.

It can be registered as a ManualDataDep
